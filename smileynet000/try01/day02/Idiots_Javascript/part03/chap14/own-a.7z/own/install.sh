#! /bin/sh


echo Installing...
sudo cp -f help.htm /etc/settings
echo
sleep 11
